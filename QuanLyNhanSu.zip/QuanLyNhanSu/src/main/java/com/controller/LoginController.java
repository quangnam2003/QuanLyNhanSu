package com.controller;

import com.model.User;
import com.service.UserService;
import com.utils.SessionManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;
    
    private UserService userService = new UserService();

    @FXML
    private void initialize() {
        // Bấm Enter trong usernameField → gọi đăng nhập
        usernameField.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                handleLogin(null);
            }
        });

        // Bấm Enter trong passwordField → gọi đăng nhập
        passwordField.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                handleLogin(null);
            }
        });
    }

    @FXML
    private void handleLogin(ActionEvent event) {
        String username = usernameField.getText().trim();
        String password = passwordField.getText();

        // Validation
        if (username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Vui lòng nhập đầy đủ thông tin!");
            return;
        }

        try {
            // Kiểm tra đăng nhập từ database
            User user = userService.authenticate(username, password);
            
            if (user != null) {
                // Đăng nhập thành công - lưu session
                SessionManager.getInstance().login(user);
                
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/main/main-layout.fxml"));
                Parent root = loader.load();

                // Lưu thông tin user vào MainController
                MainController mainController = loader.getController();
                if (mainController != null) {
                    mainController.setCurrentUser(user);
                }

                Stage stage = (Stage) usernameField.getScene().getWindow();
                stage.setScene(new Scene(root, 1000, 600));
                stage.setTitle("Quản lý nhân sự - " + user.getFullName());
                stage.show();
                
                // Clear error message
                errorLabel.setText("");
            } else {
                errorLabel.setText("Sai tên đăng nhập hoặc mật khẩu!");
            }
        } catch (Exception e) {
            errorLabel.setText("Lỗi kết nối database!");
            e.printStackTrace();
        }
    }
}
