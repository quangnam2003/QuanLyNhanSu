package com.service;

import com.model.User;
import com.utils.DBUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class UserService {

    // Kiểm tra đăng nhập - sử dụng bảng employees và roles
    public User authenticate(String username, String password) {
        String sql = """
            SELECT e.*, r.role_name, r.role_code 
            FROM employees e 
            LEFT JOIN roles r ON e.role_id = r.id 
            WHERE e.email = ? AND e.employment_status = 'Active'
        """;
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                // Tạm thời sử dụng email làm password (sẽ cải thiện sau)
                String storedPassword = rs.getString("email"); // Tạm thời
                
                if (password.equals(storedPassword) || verifyPassword(password, storedPassword)) {
                    User user = new User();
                    user.setId(rs.getInt("id"));
                    user.setUsername(rs.getString("email")); // Sử dụng email làm username
                    user.setEmail(rs.getString("email"));
                    user.setFullName(rs.getString("full_name"));
                    user.setRoleId(rs.getInt("role_id"));
                    user.setRoleName(rs.getString("role_name"));
                    user.setRoleCode(rs.getString("role_code"));
                    user.setActive(true);
                    
                    // Cập nhật last_login (có thể thêm vào bảng employees sau)
                    updateLastLogin(user.getId());
                    
                    return user;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }

    // Tạo user mới - sử dụng bảng employees
    public boolean createUser(User user) {
        String sql = "INSERT INTO employees (first_name, last_name, email, role_id, employment_status) VALUES (?, ?, ?, ?, 'Active')";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            // Tách first_name và last_name từ full_name
            String[] names = user.getFullName().split(" ", 2);
            String firstName = names.length > 0 ? names[0] : "";
            String lastName = names.length > 1 ? names[1] : "";
            
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, user.getEmail());
            stmt.setInt(4, user.getRoleId());
            
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Lấy tất cả users từ bảng employees
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = """
            SELECT e.*, r.role_name, r.role_code 
            FROM employees e 
            LEFT JOIN roles r ON e.role_id = r.id 
            WHERE e.employment_status = 'Active'
            ORDER BY e.id DESC
        """;
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("email"));
                user.setEmail(rs.getString("email"));
                user.setFullName(rs.getString("full_name"));
                user.setRoleId(rs.getInt("role_id"));
                user.setRoleName(rs.getString("role_name"));
                user.setRoleCode(rs.getString("role_code"));
                user.setActive(true);
                
                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return users;
    }

    // Cập nhật last_login
    private void updateLastLogin(int userId) {
        String sql = "UPDATE users SET last_login = ? WHERE id = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setTimestamp(1, Timestamp.valueOf(LocalDateTime.now()));
            stmt.setInt(2, userId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Kiểm tra password (placeholder cho BCrypt)
    private boolean verifyPassword(String password, String hash) {
        // TODO: Implement BCrypt verification
        return password.equals(hash); // Tạm thời so sánh trực tiếp
    }

    // Tạo hash password
    public String hashPassword(String password) {
        // TODO: Implement BCrypt hashing
        return password; // Tạm thời trả về password gốc
    }

    // Kiểm tra email đã tồn tại chưa
    public boolean isEmailExists(String email) {
        String sql = "SELECT COUNT(*) FROM employees WHERE email = ?";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return false;
    }
} 