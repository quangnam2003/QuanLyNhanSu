package com.utils;

import com.model.User;

public class SessionManager {
    private static SessionManager instance;
    private User currentUser;
    private long sessionStartTime;
    private static final long SESSION_TIMEOUT = 8 * 60 * 60 * 1000; // 8 giờ

    private SessionManager() {
        sessionStartTime = System.currentTimeMillis();
    }

    public static SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public void login(User user) {
        this.currentUser = user;
        this.sessionStartTime = System.currentTimeMillis();
    }

    public void logout() {
        this.currentUser = null;
        this.sessionStartTime = 0;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public boolean isLoggedIn() {
        return currentUser != null && !isSessionExpired();
    }

    public boolean isSessionExpired() {
        return System.currentTimeMillis() - sessionStartTime > SESSION_TIMEOUT;
    }

    public boolean hasRole(String roleCode) {
        if (!isLoggedIn()) {
            return false;
        }
        return currentUser.getRoleCode().equals(roleCode);
    }

    public boolean isAdmin() {
        return hasRole("ADMIN");
    }

    public boolean isManager() {
        return hasRole("HR_MANAGER") || hasRole("DEPT_MANAGER") || hasRole("ADMIN");
    }

    public boolean isHRStaff() {
        return hasRole("HR") || hasRole("HR_MANAGER") || hasRole("HR_DIRECTOR") || hasRole("ADMIN");
    }

    public long getSessionDuration() {
        return System.currentTimeMillis() - sessionStartTime;
    }

    public void refreshSession() {
        sessionStartTime = System.currentTimeMillis();
    }
} 