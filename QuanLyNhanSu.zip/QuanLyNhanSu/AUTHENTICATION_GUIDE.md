# 🔐 Hướng dẫn hệ thống Authentication thông minh

## 📋 Tổng quan

Hệ thống đăng nhập đã được cải tiến để sử dụng **database schema QuanLyNhanSu** với hệ thống phân quyền hoàn chỉnh.

## 🚀 Cách sử dụng


```

### 2. Tài khoản mẫu

 bạn có thể đăng nhập với các tài khoản:

| Email | Password | Role | Mô tả |
|-------|----------|------|-------|
| `admin@techcorp.com` | `admin@techcorp.com` | ADMIN | Quản trị viên hệ thống |
| `hr_manager@techcorp.com` | `hr_manager@techcorp.com` | HR_MANAGER | Trưởng phòng nhân sự |
| `hr_staff@techcorp.com` | `hr_staff@techcorp.com` | HR | Nhân viên HR |
| `dept_manager@techcorp.com` | `dept_manager@techcorp.com` | DEPT_MANAGER | Trưởng phòng ban |
| `accountant@techcorp.com` | `accountant@techcorp.com` | ACC | Kế toán |


**Lưu ý:** Hiện tại password = email (tạm thời để test)

### 3. Chạy ứng dụng



## 🔧 Tính năng mới

### ✅ Database Integration
- Sử dụng bảng `employees` và `roles` có sẵn
- Hệ thống phân quyền hoàn chỉnh
- Liên kết với cấu trúc tổ chức

### ✅ Role-based Access Control
- **ADMIN**: Toàn quyền hệ thống
- **HR_DIRECTOR**: Giám đốc nhân sự
- **HR_MANAGER**: Trưởng phòng nhân sự
- **HR**: Nhân viên HR
- **DEPT_MANAGER**: Trưởng phòng ban
- **ACC**: Kế toán

### ✅ Session Management
- Quản lý session người dùng
- Timeout tự động (8 giờ)
- Refresh session

### ✅ Security Features
- Validation input
- Error handling
- Session tracking
- Role-based permissions

## 🛠️ Cấu trúc code

### Models
- `User.java` - Entity cho người dùng (tương thích với employees)

### Services
- `UserService.java` - Business logic cho authentication

### Utils
- `SessionManager.java` - Quản lý session
- `DBUtil.java` - Kết nối database

### Controllers
- `LoginController.java` - Xử lý đăng nhập
- `MainController.java` - Lưu thông tin user hiện tại

## 🔄 Cải tiến tiếp theo

### 1. Password Security
```sql
-- Thêm cột password_hash vào bảng employees
ALTER TABLE employees ADD COLUMN password_hash VARCHAR(255);
ALTER TABLE employees ADD COLUMN last_login TIMESTAMP NULL;
```

### 2. JWT Token
- Implement JWT cho stateless authentication
- Refresh token mechanism

### 3. Two-Factor Authentication
- SMS/Email verification
- Google Authenticator

### 4. Password Policy
- Độ mạnh password
- Expiration policy
- Reset password

### 5. Audit Logging
- Log đăng nhập/đăng xuất
- Track user activities
- Security alerts

## 🚨 Lưu ý bảo mật

1. **Thay đổi password mặc định** sau khi setup
2. **Cấu hình firewall** cho database
3. **Backup database** thường xuyên
4. **Monitor login attempts** để phát hiện brute force
5. **Sử dụng HTTPS** trong production

## 📝 Database Schema

Hệ thống sử dụng schema có sẵn:

```sql
-- Bảng employees (có sẵn)
SELECT e.*, r.role_name, r.role_code 
FROM employees e 
LEFT JOIN roles r ON e.role_id = r.id 
WHERE e.employment_status = 'Active';

-- Bảng roles (có sẵn)
SELECT * FROM roles;

-- Bảng permissions (có sẵn)
SELECT * FROM permissions;

-- Bảng role_permissions (có sẵn)
SELECT rp.*, r.role_name, p.permission_name
FROM role_permissions rp
JOIN roles r ON rp.role_id = r.id
JOIN permissions p ON rp.permission_id = p.id;
```

## 🎯 Kết luận

Hệ thống authentication mới cung cấp:
- ✅ Tích hợp hoàn toàn với database hiện có
- ✅ Hệ thống phân quyền chuyên nghiệp
- ✅ Dễ quản lý user và roles
- ✅ Session management
- ✅ Scalable architecture

Đây là foundation tốt để phát triển thêm các tính năng bảo mật nâng cao! 