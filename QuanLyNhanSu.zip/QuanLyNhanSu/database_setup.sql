-- =============================================
-- SETUP DATABASE CHO HỆ THỐNG AUTHENTICATION
-- Tương thích với schema QuanLyNhanSu.sql
-- =============================================

-- Sử dụng database hiện có
USE QuanLyNhanSu;

-- Thêm dữ liệu mẫu cho employees để test authentication
INSERT INTO employees (first_name, last_name, email, phone, citizen_id, date_of_birth, gender, address, department_id, position_id, role_id, hire_date, employment_status, salary_grade) VALUES
-- Admin user
('Nguyễn', 'Văn Admin', 'admin@techcorp.com', '0901234567', '123456789012', '1990-01-01', 'Male', '123 Đường ABC, Quận 1, TP.HCM', 1, 1, 1, '2020-01-01', 'Active', 1.0),

-- HR Manager
('Trần', 'Thị HR', 'hr_manager@techcorp.com', '0901234568', '123456789013', '1985-05-15', 'Female', '456 Đường XYZ, Quận 2, TP.HCM', 1, 1, 3, '2019-06-01', 'Active', 1.2),

-- HR Staff
('Lê', 'Văn HR', 'hr_staff@techcorp.com', '0901234569', '123456789014', '1992-08-20', 'Male', '789 Đường DEF, Quận 3, TP.HCM', 1, 3, 4, '2021-03-15', 'Active', 1.0),

-- Department Manager
('Phạm', 'Thị Manager', 'dept_manager@techcorp.com', '0901234570', '123456789015', '1988-12-10', 'Female', '321 Đường GHI, Quận 7, TP.HCM', 3, 5, 5, '2020-09-01', 'Active', 1.3),

-- Accountant
('Hoàng', 'Văn Accountant', 'accountant@techcorp.com', '0901234571', '123456789016', '1991-03-25', 'Male', '654 Đường JKL, Quận 5, TP.HCM', 2, 5, 6, '2021-01-10', 'Active', 1.1),

-- Regular Employee
('Võ', 'Thị Employee', 'employee@techcorp.com', '0901234572', '123456789017', '1995-07-08', 'Female', '987 Đường MNO, Quận 10, TP.HCM', 3, 7, 6, '2022-02-20', 'Active', 1.0);

-- Thêm dữ liệu mẫu cho departments nếu chưa có
INSERT IGNORE INTO departments (department_code, department_name, description, address, phone, email) VALUES
('HR', 'Phòng Nhân sự', 'Quản lý nhân sự, tuyển dụng và đào tạo', 'Tầng 3 - Tòa nhà A', '0281234567', 'hr@techcorp.com'),
('ACC', 'Phòng Kế toán', 'Xử lý tài chính, lương và chi phí', 'Tầng 2 - Tòa nhà A', '0282345678', 'acc@techcorp.com'),
('DEV', 'Phòng Phát triển phần mềm', 'Phát triển hệ thống phần mềm', 'Tầng 4 - Tòa nhà B', '0283456789', 'dev@techcorp.com');

-- Thêm dữ liệu mẫu cho positions nếu chưa có
INSERT IGNORE INTO positions (position_code, position_name, department_id, level, description, requirements) VALUES
('HR_MANAGER', 'Trưởng phòng Nhân sự', 1, 4, 'Quản lý nhân sự công ty', '3+ năm kinh nghiệm quản lý'),
('HR_GENERALIST', 'Nhân viên Hành chính - Nhân sự', 1, 2, 'Hỗ trợ các nghiệp vụ nhân sự', 'Thành thạo Excel, quản lý hồ sơ'),
('ACC_MANAGER', 'Trưởng phòng Kế toán', 2, 4, 'Phụ trách tài chính & lương', 'Kế toán trưởng, CPA là lợi thế'),
('DEV_LEAD', 'Trưởng nhóm Phát triển', 3, 4, 'Quản lý team lập trình viên', 'Kinh nghiệm fullstack, leadership'),
('BACKEND_DEV', 'Lập trình viên Backend', 3, 2, 'Phát triển API, xử lý logic server', 'Thành thạo Java/Spring, RESTful');

-- Thêm dữ liệu mẫu cho roles nếu chưa có
INSERT IGNORE INTO roles (role_name, role_code, description) VALUES
('Admin', 'ADMIN', 'Quản trị toàn bộ hệ thống'),
('Giám đốc nhân sự', 'HR_DIRECTOR', 'Giám sát toàn bộ hoạt động nhân sự'),
('Trưởng phòng nhân sự', 'HR_MANAGER', 'Quản lý nhân sự và các HR Staff'),
('HR Staff', 'HR', 'Chuyên viên nhân sự'),
('Trưởng phòng ban', 'DEPT_MANAGER', 'Quản lý phòng ban của mình'),
('Accountant', 'ACC', 'Phụ trách lương và tài chính');

-- Cập nhật department_id và position_id cho employees
UPDATE employees SET department_id = 1, position_id = 1 WHERE email = 'admin@techcorp.com';
UPDATE employees SET department_id = 1, position_id = 1 WHERE email = 'hr_manager@techcorp.com';
UPDATE employees SET department_id = 1, position_id = 2 WHERE email = 'hr_staff@techcorp.com';
UPDATE employees SET department_id = 3, position_id = 4 WHERE email = 'dept_manager@techcorp.com';
UPDATE employees SET department_id = 2, position_id = 3 WHERE email = 'accountant@techcorp.com';
UPDATE employees SET department_id = 3, position_id = 5 WHERE email = 'employee@techcorp.com';

-- Tạo index để tối ưu performance
CREATE INDEX IF NOT EXISTS idx_employee_email ON employees(email);
CREATE INDEX IF NOT EXISTS idx_employee_status ON employees(employment_status);
CREATE INDEX IF NOT EXISTS idx_employee_role ON employees(role_id);

-- Hiển thị thông tin tài khoản test
SELECT 
    e.id,
    e.full_name,
    e.email,
    r.role_name,
    r.role_code,
    e.employment_status
FROM employees e
LEFT JOIN roles r ON e.role_id = r.id
WHERE e.employment_status = 'Active'
ORDER BY e.id; 